"""Independent file-integrity and vector-level check of the INT16 handoff."""

from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np


root = Path(sys.argv[1])
vectors = root / "software/precision/results/int16_vectors"
manifest_path = vectors / "manifest.json"
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
config_path = root / "software/precision/configs/int16_config.json"
assert sha256(config_path.read_bytes()).hexdigest() == manifest["config_sha256"]
assert len(manifest["layers"]) == 12


def signed(values: np.ndarray, bits: int) -> np.ndarray:
    return np.where(values >= (1 << (bits - 1)), values - (1 << bits), values)


total = 0
for layer in manifest["layers"]:
    index = layer["layer"]
    folder = vectors / f"layer_{index:02d}"
    arrays = {}
    for name, record in layer["files"].items():
        path = folder / record["file"]
        payload = path.read_bytes()
        assert sha256(payload).hexdigest() == record["sha256"], path
        lines = payload.decode("ascii").splitlines()
        assert len(lines) == record["word_count"], path
        assert record["byte_count"] == 2 * len(lines), path
        assert all(len(line) == 4 and all(char in "0123456789abcdef" for char in line) for line in lines), path
        arrays[name] = np.asarray([int(line, 16) for line in lines], dtype=np.int64)
    x = signed(arrays["x"], 16).reshape(99, 64)
    w = signed(arrays["w"], 16).reshape(64, 256)
    low = arrays["bias"][0::2]
    high = arrays["bias"][1::2]
    bias = signed(low | (high << 16), 32)
    acc = x @ w + bias
    shift = layer["format"]["x_frac"] + layer["format"]["w_frac"] - layer["format"]["y_frac"]
    divisor = 1 << shift
    quotient, remainder = np.divmod(acc, divisor)
    rounded = quotient + ((remainder > divisor // 2) | ((remainder == divisor // 2) & (quotient % 2 != 0)))
    rounded = np.clip(rounded, -32767, 32767)
    actual = signed(arrays["y_expected"], 16).reshape(99, 256)
    if not np.array_equal(actual, rounded):
        row, col = np.argwhere(actual != rounded)[0]
        raise AssertionError(f"layer {index:02d}, row {row}, col {col}: stored={actual[row,col]}, recalculated={rounded[row,col]}")
    total += actual.size
print(f"PASS: 12 layers, 48 word images, {total} independently recomputed output words")
print(f"manifest_sha256={sha256(manifest_path.read_bytes()).hexdigest()}")
