"""Cross-check candidate INT16 word images against archived sequential FP32 Golden."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from software.precision.study import file_hash, load_case


def check(input_root: Path, vector_dir: Path) -> dict[str, object]:
    packed = json.loads((input_root / "fp32_12_layer_pack_summary.json").read_text(encoding="utf-8"))
    vectors = json.loads((vector_dir / "manifest.json").read_text(encoding="utf-8"))
    if packed.get("layer_count") != 12 or len(vectors.get("layers", [])) != 12:
        raise ValueError("need 12 FP32 Golden and INT16 vector layers")
    rows = []
    for layer in range(12):
        record = packed["layers"][layer]
        vector = vectors["layers"][layer]
        if record["layer"] != layer or vector["layer"] != layer:
            raise ValueError("layer order differs")
        npz_path = input_root / f"layer_{layer:02d}.npz"
        if file_hash(npz_path) != record["input_sha256"] or file_hash(npz_path) != vector["source_npz_sha256"]:
            raise ValueError(f"layer {layer}: NPZ hash mismatch")
        fp_path = input_root / f"fp32_layer{layer:02d}" / "expected.bin"
        if file_hash(fp_path) != record["expected_sha256"]:
            raise ValueError(f"layer {layer}: FP32 expected hash mismatch")
        fp = np.fromfile(fp_path, dtype="<f4").astype(np.float64).reshape(99, 256)
        y_path = vector_dir / f"layer_{layer:02d}" / "y_expected.mem"
        if file_hash(y_path) != vector["files"]["y_expected"]["sha256"]:
            raise ValueError(f"layer {layer}: INT16 expected hash mismatch")
        words = np.array([int(line, 16) for line in y_path.read_text(encoding="ascii").splitlines()], dtype=np.uint16)
        if words.size != 99 * 256:
            raise ValueError(f"layer {layer}: wrong INT16 output word count")
        quant = words.view(np.int16).astype(np.float64).reshape(99, 256) / (1 << vector["format"]["y_frac"])
        model = load_case(npz_path)["y_float"]
        def metric(actual: np.ndarray, reference: np.ndarray) -> float:
            return float(np.sqrt(np.sum(np.square(actual - reference)) / actual.size)
                         / max(np.sqrt(np.sum(np.square(reference)) / reference.size), 1e-8))
        rows.append({"layer": layer,
                     "int16_vs_fp32_nrmse": metric(quant, fp),
                     "model_dense_vs_fp32_nrmse": metric(model, fp),
                     "int16_vs_fp32_max_abs": float(np.max(np.abs(quant - fp))),
                     "fp32_expected_sha256": record["expected_sha256"],
                     "int16_y_expected_sha256": vector["files"]["y_expected"]["sha256"]})
    worst = max(rows, key=lambda row: row["int16_vs_fp32_nrmse"])
    return {"status": "selected INT16 candidate vs archived sequential FP32 Golden",
            "fp32_pack_summary_sha256": file_hash(input_root / "fp32_12_layer_pack_summary.json"),
            "int16_vector_manifest_sha256": file_hash(vector_dir / "manifest.json"),
            "worst_layer": worst["layer"], "maximum_12_layer_nrmse": worst["int16_vs_fp32_nrmse"],
            "layers": rows}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--vector-dir", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    if args.report.exists():
        parser.error(f"preserving existing report: {args.report}")
    report = check(args.input_root, args.vector_dir)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"worst layer {report['worst_layer']:02d}, INT16/FP32 NRMSE {report['maximum_12_layer_nrmse']:.6%}")


if __name__ == "__main__":
    main()
