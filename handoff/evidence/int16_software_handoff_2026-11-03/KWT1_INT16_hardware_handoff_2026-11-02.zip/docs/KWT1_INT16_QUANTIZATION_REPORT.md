# KWT-1 INT16 量化实验报告（2026-11-02）

> **结论范围：**项目已决定研究 INT16。本报告完成了 **1 条真实录音 × 12 层 FFN1** 的整数计算实验。该录音的官方训练／验证划分尚未核实，且本轮用同一条录音选缩放系数并计算误差。因此下列数字是**探索性数值结果**，不能作为赛事 3% 指标的正式验收，也不表示量化 RTL 已通过。

## 1. 输入、版本与实际完成的工作

- 软件工作分支：`software`；开始时 HEAD `e4892f712d010de6d5cfe86bf6e7adee73d820ea`。工作区原有的驱动、FP32 比较器及历史交接文件修改均被保留；没有提交或推送。
- ARM Keyword Transformer 固定源码：`237e4097afd4f6851e0b82f0a8d65c2dfe8eae30`；模型 `models_data_v2_12_labels/kwt1/best_weights`。权重 `best_weights.index` SHA-256 为 `5a60a0fa78a1855572084a42669768e2998d37e7d93c833962960fdb0db70fbc`，`best_weights.data-00000-of-00001` 为 `ae993f6ed995938c1ab584b0857b35ca18f31f88001c7e17c7d7c3868bd33ad3`。
- 真实录音：`eight/750e3e75_nohash_0.wav`，SHA-256 `d72dd7e4654e12b92a29c1bb247ef30886b632a7a14424ab4abb85e6272ae27a`。已从 [ARM 官方仓库指定的 TensorFlow 数据压缩包](https://github.com/ARM-software/keyword-transformer#download-google-speech-commands)开头直接读到同名 WAV，文件哈希相同。原始导出清单 SHA-256 `e2a17b6bf0e7045d3c31ae697a062d97740d218a63e181fbfd2d898f5e3cb901`，其 `split=unverified`。流式提取官方 `validation_list.txt`／`testing_list.txt` 的连接在中途以 `tarfile.ReadError: unexpected end of data` 结束；**未取得官方划分名单**。
- 12 个 `layer_00.npz` 至 `layer_11.npz` 均与导出清单的 SHA-256 一致。每层含 `X[99,64]`、`W[64,256]`、`bias[256]`、模型 Dense 输出 `y_float[99,256]`；逐层独立 `X @ W + bias` 与所存 `y_float` 一致。每层 25,344 个输出，全计 304,128 个；这是**一条录音的 12 层，不是 12 条录音**。
- 直接复用了 `software/precision/study.py` 的来源检查与数据读取、既有整数原型的位宽边界函数和原有 FP32 Golden。旧 Q16.8 使用中点远离零舍入；本轮新建独立的最近偶数 INT16 整数路径，避免改变历史原型或 FP32 合同。

## 2. 实际 INT16 运算定义

选出的**暂定硬件候选**是逐层最大绝对值的二进制缩放：X、W、Y 均为有符号 16 位二补数、零点 0，数值量化范围 `[-32767,32767]`；`-32768` 保留，不由软件打包器产生。输入、权重和 bias 量化均采用最近偶数舍入，然后按各自宽度饱和。`qX = RNE(X × 2^12)`，`qW = RNE(W × 2^16)`；bias 为有符号 32 位、与乘积共用 `2^28` 尺度：`qB = RNE(bias × 2^28)`。乘积使用有符号 32 位，累加器推荐有符号 **38 位**。每个输出从 0 开始，按 `k=0…63` 加 64 个整数乘积，最后只加一次 `qB`，再以最近偶数舍入右移并饱和为 INT16。

| 层 | X 小数位 | W 小数位 | Y 小数位 | 输出右移 | 本轮 NRMSE |
|---:|---:|---:|---:|---:|---:|
| 00 | 12 | 16 | 13 | 15 | 0.00945% |
| 01 | 12 | 16 | 12 | 16 | 0.01345% |
| 02 | 12 | 16 | 12 | 16 | **0.01549%** |
| 03 | 12 | 16 | 13 | 15 | 0.01191% |
| 04 | 12 | 16 | 13 | 15 | 0.01294% |
| 05 | 12 | 16 | 13 | 15 | 0.01247% |
| 06 | 12 | 16 | 13 | 15 | 0.01352% |
| 07 | 12 | 16 | 13 | 15 | 0.01234% |
| 08 | 12 | 16 | 13 | 15 | 0.01297% |
| 09 | 12 | 16 | 13 | 15 | 0.01184% |
| 10 | 12 | 16 | 13 | 15 | 0.01043% |
| 11 | 12 | 16 | 12 | 16 | 0.01189% |

完整精度、RMSE、最大绝对误差、饱和比例及各层累加界见 `software/precision/results/int16_per_layer.csv`。每条样本的记录见 `int16_per_sample.csv`。这里的 NRMSE 按任务书指定口径：同一层所有有效输出先汇总误差平方和与参考平方和，`sqrt(SSE/N) / max(sqrt(REFSQ/N),1e-8)`，最后取 12 层最大值；没有平均 12 个百分比。

## 3. 四种 INT16 标定实验

所有候选均使用真实的 INT16×INT16 整数乘法、逐 K 整数累加、INT32 bias、最终整数移位；`y_float` 只用于误差参考及选择输出缩放。当前**标定数据与评估数据重合**，下表不能外推到其他录音。

| 缩放方案 | 12 层最大 NRMSE | 最差层 | 本样本饱和次数 | 判断 |
|---|---:|---:|---|---|
| 全部层共用最大绝对值尺度 | 0.020380% | 06 | 全部 0 | 简单，但输出精度略低 |
| **逐层最大绝对值尺度（选中）** | **0.015488%** | **02** | **X/W/bias/MAC/bias 加法/Y 全部 0** | 只需每层三个二进制指数 |
| 逐层 99.9 百分位 | 2.546337% | 05 | X 10、W 52、Y 18；其余 0 | 截顶带来明显误差；本轮不选 |
| 逐输出通道 W 最大绝对值尺度 | 0.014152% | 02 | 全部 0 | 比逐层仅改善约 0.00134 个百分点，却需每层 256 个 W 指数和逐通道 bias／输出处理；本轮不选 |

已完成 12 层所有 19,464,192 次整数 MAC 的软件执行。选中格式在这条录音上未发生操作数、bias、累加器或输出饱和；这只说明该样本的范围足够。模型 Dense 输出与此前已归档的逐 K 非融合 FP32 Golden 的最大层 NRMSE 为 `9.6796×10^-8`，属于两种浮点计算顺序的微小差异。将选中的 INT16 字镜像与该 FP32 Golden 另行交叉比较，最差层仍为 02、NRMSE 约 0.015488%；没有把这项浮点差异计作量化器错误。

## 4. 累加器位宽证明

本轮逐层对量化后的真实 X/W/bias 求 `max_row,column (Σ_k |qX[row,k]·qW[k,column]| + |qB[column]|)`。该值界定任意累加顺序中每个部分和的绝对值；选中格式在当前样本中 12 层所需位宽均为 **32 位**（逐层绝对上界约 `1.27×10^9` 至 `1.79×10^9`，详见 CSV）。这不是所有未来输入都安全的证明。

对**任意合法** `qX,qW∈[-32767,32767]`、K=64、任意有符号 32 位 `qB`，保守绝对界为 `64×32767² + 2³¹ = 70,862,766,144`。有符号 37 位的最大值 `2³⁶−1` 装不下；有符号 38 位的最大值 `2³⁷−1` 可以装下。因此以本合同的完整输入范围计算，**最小安全宽度与推荐实现宽度均为 38 位**。乘积在有符号 32 位中计算；38 位累加器在 K=64 内不应溢出。K=32 分块时必须原样延续整数部分和，bias 只在 64 项全部完成后加入。

## 5. 理论存储与数据搬运

按一个 `99×64 · 64×256 + 256` 的 FFN1 调用、每个张量只读／写一次估计：

| 格式 | X | W | bias | Y | X+W+b+Y |
|---|---:|---:|---:|---:|---:|
| FP32 | 25,344 B | 65,536 B | 1,024 B | 101,376 B | 193,280 B |
| 选中 INT16（bias INT32） | 12,672 B | 32,768 B | 1,024 B | 50,688 B | 97,152 B |

FFN1 权重比 FP32 少 **32,768 B／层（50%）**；12 层 FFN1 权重从 786,432 B 降到 393,216 B。上述一次性四类张量总量少 96,128 B／层（**49.735%**）。如果只看 X/W/bias 的装载量，从 91,904 B 降到 46,464 B，少约 **49.44%**。逐层格式理论上至少需要 12×3 个二进制指数；其编码、寄存器、对齐及重复搬运还未由硬件定义。这里没有实测 SRAM 占用、System Bus 流量、芯片面积、功耗、频率或吞吐提升。

## 6. 复现命令和交付数据

本轮执行环境：Windows；现有 Python 3.12.14、NumPy 2.3.5；没有安装新 EDA 或重新训练模型。从仓库根目录执行：

```text
<python> -B -m software.precision.int16_round01 calibrate --calibration-root C:\Users\Lenovo\Documents\Codex\2026-10-16\kwt1-real-audio-smoke --config software\precision\configs\int16_config.json
<python> -B -m software.precision.int16_round01 evaluate --input-root C:\Users\Lenovo\Documents\Codex\2026-10-16\kwt1-real-audio-smoke --config software\precision\configs\int16_config.json --output-dir software\precision\results
<python> -B -m software.precision.export_int16_vectors --input-root C:\Users\Lenovo\Documents\Codex\2026-10-16\kwt1-real-audio-smoke --config software\precision\configs\int16_config.json --output-dir software\precision\results\int16_vectors
<python> -B -m software.precision.check_int16_vs_fp32 --input-root C:\Users\Lenovo\Documents\Codex\2026-10-16\kwt1-real-audio-smoke --vector-dir software\precision\results\int16_vectors --report software\precision\results\int16_fp32_crosscheck.json
<python> -B -m unittest software.tests.test_int16_numeric -v
```

`<python>` 为 `C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe`。校准和输出命令为保护已有文件而拒绝覆盖；复现时请使用新的输出目录。已运行的 INT16 数值针对性测试为 **5/5 通过**。此前的 `software.tests.test_precision_study` **7/7**、`software.tests.test_compare_layer_scales` **3/3**、`software.tests.test_precision_export_round01` **3/3** 也已通过；它们验证旧扫描器与结果表，不代替本轮 INT16 真值实验。

关键交付指纹：`int16_config.json` SHA-256 `4dab987eac7112122695b7dab1f93585c86abf225d0859b132f9f2899321d6a5`；`int16_summary.json` SHA-256 `9edac56e3fe179586ce3db8010f2e5f670c08e54724f3c79694cb788680726d8`。`int16_vectors/manifest.json` 列出 12 层 X/W/bias/预期 Y 的 16 位字镜像、格式和逐文件哈希；bias 每个 INT32 按**低 16 位字、再高 16 位字**排列。所有地址仅为文件内字索引，物理地址仍待硬件接口确认。

交付前另用一份不调用导出器或量化模型的独立检查脚本，重新核验了 **48 个镜像文件的 SHA-256 和字数**，再从文件中的有符号 X/W/bias 以整数矩阵乘法与最近偶数整数右移，重新计算并比较 **304,128/304,128 个 Y 字**，结果通过。镜像清单 `manifest.json` 的 SHA-256 是 `107e6ae9fa952c4129020d93c896c3cdbffc51de024d4884f7d4d07c8d429161`。同轮相关针对性测试合计 **18/18 通过**；这是软件自检，尚未验证任何 INT16 RTL。独立检查脚本随硬件交付 ZIP 的 `tools/` 提供。

## 7. 能交给硬件的内容与仍缺的证据

可以交付**可运行的候选数值合同、完整 12 层的 INT16 字镜像、逐层软件期望结果及哈希**，供硬件实现估算和小用例 RTL 对拍。正式冻结之前仍需要：(1) 官方划分名单与**独立的训练标定样本和多条验证样本**；(2) 硬件确认最近偶数舍入、`-32768`、38 位累加、K=32 跨块部分和、指数配置方式；(3) INT16 RTL 的逐字输出和综合／PPA 结果。当前无法正式签署“3% 达标”或“量化硬件已实现”。

详见 [INT16 数值合同](KWT1_INT16_NUMERICAL_CONTRACT.md)与[硬件交接](KWT1_INT16_HANDOFF_TO_HARDWARE.md)。
