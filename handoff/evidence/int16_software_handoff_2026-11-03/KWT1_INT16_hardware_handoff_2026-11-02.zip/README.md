# KWT-1 INT16 candidate handoff, 2026-11-02

This package contains one real audio sample across 12 FFN1 layers. Its official split is unverified; calibration and evaluation reuse the same sample. It is a software candidate, not a formal accuracy or RTL acceptance result.

Start with docs/KWT1_INT16_HANDOFF_TO_HARDWARE.md. Check SHA256SUMS.txt after extraction. With Python and NumPy installed, run: python tools/verify_int16_package.py <extracted package root>. The source files under software/precision are from the team repository and may need its other modules for full calibration reproduction.
